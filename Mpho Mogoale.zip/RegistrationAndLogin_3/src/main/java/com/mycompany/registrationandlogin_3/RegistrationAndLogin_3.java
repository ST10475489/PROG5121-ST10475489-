/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationandlogin_3;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.Pattern;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author RC_Student_lab
 */
public class RegistrationAndLogin_3 {
    private JFrame frame;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    
    // User data
    private String username;
    private String firstName;
    private String lastName;
    private String password;
    private String phoneNumber;
    private boolean isRegistered = false;
    
    // GUI components
    private JTextField firstNameField, lastNameField, usernameField;
    private JPasswordField passwordField;
    private JTextField phoneField;
    private JLabel messageLabel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new RegistrationAndLogin_3().createAndShowGUI();
        });
    }

    private void createAndShowGUI() {
        frame = new JFrame("Registration and Login System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);
        
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        
        createWelcomePanel();
        createRegistrationPanel();
        createLoginPanel();
        
        frame.add(mainPanel);
        frame.setVisible(true);
    }

    private void createWelcomePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        JLabel titleLabel = new JLabel("Welcome to Registration and Login System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        
        JButton registerBtn = new JButton("Register");
        registerBtn.addActionListener(e -> cardLayout.show(mainPanel, "register"));
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(registerBtn, gbc);
        
        JButton loginBtn = new JButton("Login");
        loginBtn.addActionListener(e -> cardLayout.show(mainPanel, "login"));
        gbc.gridx = 1;
        panel.add(loginBtn, gbc);
        
        mainPanel.add(panel, "welcome");
    }

    private void createRegistrationPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Title
        JLabel titleLabel = new JLabel("Registration Form");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        
        // Form fields
        gbc.gridwidth = 1;
        gbc.gridy++;
        panel.add(new JLabel("First Name:"), gbc);
        gbc.gridx = 1;
        firstNameField = new JTextField(20);
        panel.add(firstNameField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Last Name:"), gbc);
        gbc.gridx = 1;
        lastNameField = new JTextField(20);
        panel.add(lastNameField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Username (with _, ≤5 chars):"), gbc);
        gbc.gridx = 1;
        usernameField = new JTextField(20);
        panel.add(usernameField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Password (8+ chars, 1 cap, 1 num, 1 special):"), gbc);
        gbc.gridx = 1;
        passwordField = new JPasswordField(20);
        panel.add(passwordField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Phone (+country code):"), gbc);
        gbc.gridx = 1;
        phoneField = new JTextField(20);
        panel.add(phoneField, gbc);
        
        // Message label
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        messageLabel = new JLabel(" ");
        messageLabel.setForeground(Color.RED);
        panel.add(messageLabel, gbc);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> cardLayout.show(mainPanel, "welcome"));
        buttonPanel.add(backBtn);
        
        JButton registerBtn = new JButton("Register");
        registerBtn.addActionListener(e -> registerUser());
        buttonPanel.add(registerBtn);
        
        gbc.gridy++;
        panel.add(buttonPanel, gbc);
        
        mainPanel.add(panel, "register");
    }

    private void createLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Title
        JLabel titleLabel = new JLabel("Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        
        // Form fields
        gbc.gridwidth = 1;
        gbc.gridy++;
        panel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        JTextField loginUserField = new JTextField(20);
        panel.add(loginUserField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        JPasswordField loginPassField = new JPasswordField(20);
        panel.add(loginPassField, gbc);
        
        // Message label
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        JLabel loginMessageLabel = new JLabel(" ");
        loginMessageLabel.setForeground(Color.RED);
        panel.add(loginMessageLabel, gbc);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> cardLayout.show(mainPanel, "welcome"));
        buttonPanel.add(backBtn);
        
        JButton loginBtn = new JButton("Login");
        loginBtn.addActionListener(e -> {
            boolean success = loginUser(loginUserField.getText(), new String(loginPassField.getPassword()));
            if (success) {
                loginMessageLabel.setForeground(Color.GREEN);
                loginMessageLabel.setText(String.format("Welcome %s %s, it is great to see you again.", firstName, lastName));
            } else {
                loginMessageLabel.setForeground(Color.RED);
                loginMessageLabel.setText("Username or password incorrect, please try again.");
            }
        });
        buttonPanel.add(loginBtn);
        
        gbc.gridy++;
        panel.add(buttonPanel, gbc);
        
        mainPanel.add(panel, "login");
    }

    private void registerUser() {
        firstName = firstNameField.getText();
        lastName = lastNameField.getText();
        username = usernameField.getText();
        password = new String(passwordField.getPassword());
        phoneNumber = phoneField.getText();
        
        StringBuilder errors = new StringBuilder();
        
        if (!checkUserName(username)) {
            errors.append("Username is not correctly formatted.\n");
        }
        if (!checkPasswordComplexity(password)) {
            errors.append("Password does not meet requirements.\n");
        }
        if (!checkCellPhoneNumber(phoneNumber)) {
            errors.append("Cell phone number incorrectly formatted.\n");
        }
        
        if (errors.length() > 0) {
            messageLabel.setText("<html>" + errors.toString().replace("\n", "<br>") + "</html>");
        } else {
            isRegistered = true;
            messageLabel.setForeground(Color.GREEN);
            messageLabel.setText("Registration successful!");
            clearRegistrationForm();
            cardLayout.show(mainPanel, "welcome");
        }
    }

    private boolean loginUser(String inputUsername, String inputPassword) {
        if (!isRegistered) {
            JOptionPane.showMessageDialog(frame, "Please register first.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return inputUsername.equals(username) && inputPassword.equals(password);
    }

    private boolean checkUserName(String username) {
        return username != null && username.length() <= 5 && username.contains("_");
    }

    private boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;
        
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecialChar = true;
            }
            
            if (hasCapital && hasNumber && hasSpecialChar) {
                break;
            }
        }
        
        return hasCapital && hasNumber && hasSpecialChar;
    }

    private boolean checkCellPhoneNumber(String phoneNumber) {
        if (phoneNumber == null) return false;
        String regex = "^\\+[1-9]\\d{0,2}\\d{7,15}$";
        return Pattern.matches(regex, phoneNumber);
    }

    private void clearRegistrationForm() {
        firstNameField.setText("");
        lastNameField.setText("");
        usernameField.setText("");
        passwordField.setText("");
        phoneField.setText("");
    }
}

public class RegistrationAndLogin_3 {
    

    // Messaging system
    private MessageManager messageManager = new MessageManager();

    public static void main(String[] args) {
        
    }

    private void createAndShowGUI() {
        frame = new JFrame("Registration and Login System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);
        frame.setLocationRelativeTo(null);
        
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        
        createWelcomePanel();
        createRegistrationPanel();
        createLoginPanel();
        createQuickChatPanel(); // New panel for messaging
        
        frame.add(mainPanel);
        frame.setVisible(true);
    }

    // [Previous methods: createWelcomePanel, createRegistrationPanel, createLoginPanel remain the same]
    // Only showing new/changed methods below

    private void createQuickChatPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        JLabel welcomeLabel = new JLabel("Welcome to QuickChat", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(welcomeLabel, BorderLayout.NORTH);
        
        JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        
        JButton sendMsgBtn = new JButton("1) Send Messages");
        sendMsgBtn.addActionListener(e -> sendMessages());
        buttonPanel.add(sendMsgBtn);
        
        JButton showMsgBtn = new JButton("2) Show recently sent messages");
        showMsgBtn.addActionListener(e -> 
            JOptionPane.showMessageDialog(frame, "Coming Soon.", "Information", JOptionPane.INFORMATION_MESSAGE));
        buttonPanel.add(showMsgBtn);
        
        JButton quitBtn = new JButton("3) Quit");
        quitBtn.addActionListener(e -> {
            isLoggedIn = false;
            cardLayout.show(mainPanel, "welcome");
        });
        buttonPanel.add(quitBtn);
        
        panel.add(buttonPanel, BorderLayout.CENTER);
        mainPanel.add(panel, "quickchat");
    }

    private boolean loginUser(String inputUsername, String inputPassword) {
        if (!isRegistered) {
            JOptionPane.showMessageDialog(frame, "Please register first.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        boolean success = inputUsername.equals(username) && inputPassword.equals(password);
        if (success) {
            isLoggedIn = true;
            cardLayout.show(mainPanel, "quickchat");
        }
        return success;
    }

    private void sendMessages() {
        if (!isLoggedIn) {
            JOptionPane.showMessageDialog(frame, "Please login first.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String numMessagesStr = JOptionPane.showInputDialog(frame, "How many messages do you want to send?");
        if (numMessagesStr == null) return;
        
        try {
            int numMessages = Integer.parseInt(numMessagesStr);
            
            for (int i = 0; i < numMessages; i++) {
                Message message = createMessage();
                if (message != null) {
                    int choice = getMessageActionChoice();
                    messageManager.processMessage(message, choice);
                }
            }
            
            JOptionPane.showMessageDialog(frame, 
                "Total messages sent: " + messageManager.getTotalMessagesSent());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid number.");
        }
    }

    private Message createMessage() {
        String recipient = JOptionPane.showInputDialog(frame, 
            "Enter recipient phone number (with international code, max 10 chars):");
        if (recipient == null) return null;
        
        if (!checkCellPhoneNumber(recipient)) {
            JOptionPane.showMessageDialog(frame, 
                "Cell phone number is incorrectly formatted or does not contain an international code.");
            return null;
        }
        
        String content = JOptionPane.showInputDialog(frame, "Enter your message (max 250 chars):");
        if (content == null) return null;
        
        if (content.length() > 250) {
            JOptionPane.showMessageDialog(frame, 
                "Message exceeds 250 characters by " + (content.length() - 250) + 
                ", please reduce size.");
            return null;
        }
        
        String messageId = messageManager.generateMessageId();
        int messageNumber = messageManager.getNextMessageNumber();
        
        return new Message(messageId, messageNumber, recipient, content);
    }

    private int getMessageActionChoice() {
        Object[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        int choice = JOptionPane.showOptionDialog(frame,
            "Choose an action for the message:",
            "Message Action",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]);
        
        return choice + 1; // Convert to 1-based index
    }

    // [Keep all other existing methods: registerUser, checkUserName, checkPasswordComplexity, etc.]
}

class Message {
    private String messageId;
    private int numSentMessages;
    private String recipient;
    private String content;
    private String messageHash;
    
    public Message(String messageId, int numSentMessages, String recipient, String content) {
        this.messageId = messageId;
        this.numSentMessages = numSentMessages;
        this.recipient = recipient;
        this.content = content;
        this.messageHash = createMessageHash();
    }
    
    public boolean checkMessageId() {
        return messageId != null && messageId.length() <= 10;
    }
    
    public boolean checkRecipientCell() {
        return recipient != null && recipient.length() <= 10 && recipient.startsWith("+");
    }
    
    public String createMessageHash() {
        String[] words = content.split(" ");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        
        String hash = messageId.substring(0, 2) + ":" + numSentMessages + ":" + 
                     firstWord.toUpperCase() + lastWord.toUpperCase();
        this.messageHash = hash;
        return hash;
    }
    
    public String processMessageChoice(int choice) {
        switch (choice) {
            case 1: return "Message successfully sent.";
            case 2: return "Press 0 to delete message.";
            case 3: return "Message successfully stored.";
            default: return "Invalid choice.";
        }
    }
    
    public String printMessage() {
        return "Message ID: " + messageId + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + content;
    }
    
    // Getters
    public String getMessageId() { return messageId; }
    public int getNumSentMessages() { return numSentMessages; }
    public String getRecipient() { return recipient; }
    public String getContent() { return content; }
    public String getMessageHash() { return messageHash; }
}

class MessageManager {
    private List<Message> messages = new ArrayList<>();
    private int totalMessagesSent = 0;
    private int messageCounter = 1;
    
    public void processMessage(Message message, int choice) {
        String result = message.processMessageChoice(choice);
        
        if (choice == 1) { // Send
            messages.add(message);
            totalMessagesSent++;
            JOptionPane.showMessageDialog(null, message.printMessage());
        } else if (choice == 3) { // Store
            storeMessageToJson(message);
        }
        
        JOptionPane.showMessageDialog(null, result);
    }
    
    public int getTotalMessagesSent() {
        return totalMessagesSent;
    }
    
    public String generateMessageId() {
        Random random = new Random();
        long id = 1000000000L + random.nextInt(900000000);
        return String.valueOf(id);
    }
    
    private void storeMessageToJson(Message message) {
        JSONObject jsonMessage = new JSONObject();
        jsonMessage.put("messageId", message.getMessageId());
        jsonMessage.put("messageHash", message.getMessageHash());
        jsonMessage.put("recipient", message.getRecipient());
        jsonMessage.put("content", message.getContent());
        
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(jsonMessage);
        
        try (FileWriter file = new FileWriter("stored_messages.json", true)) {
            file.write(jsonArray.toString() + "\n");
            file.flush();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error storing message: " + e.getMessage());
        }
    }
    
    public int getNextMessageNumber() {
        return messageCounter++;
    }
}



